jQuery( document ).ready( function( $ ){
	if( $.fn.dataTable ){
		$( '.data-table' ).dataTable();
	}
	
	if( $.fn.chosen ){
		$( '.chosen' ).chosen();
	}
	
	if( $.fn.datetimepicker ){
		
		$( '.datetimepicker, .timepicker, .datepicker' ).each( function(){
			
			var default_format = '';
			if( $( this ).is( '.datetimepicker' ) )
				default_format = 'YYYY-MM-DD HH:mm:ss';
			else if( $( this ).is( '.timepicker' ) )
				default_format = 'HH:mm:ss';
			else if( $( this ).is( '.datepicker' ) )
				default_format = 'YYYY-MM-DD';
		
			var save_format = ( $( this ).attr( 'data-save_format' ) != undefined )?$( this ).attr( 'data-save_format' ):default_format;
			var visible_format = ( $( this ).attr( 'data-visible_format' ) != undefined )?$( this ).attr( 'data-visible_format' ):save_format;
			if( visible_format != save_format ){
				$picker_input = $( this ).clone( true );
				$( this ).attr( 'type', 'hidden' );
				$( this ).after( $picker_input );
				$picker_input.attr( 'data-name', $( this ).attr( 'name' ) );
				$picker_input.attr( 'name', '' );
				$picker_input.attr( 'id', $( this ).attr( 'id' ) + '_' );
				
				$picker_input.datetimepicker({
					format: visible_format
				}).on( "dp.change", function(e) {
					var id = $( this ).attr( 'id' ).substr( 0, $( this ).attr( 'id' ).length - 1 );
					$hidden_input = $( '#' + id );
					var val = moment( $( this ).val(), visible_format ).format( save_format );
					if( val.indexOf( 'Invalid' ) == -1  )
						$hidden_input.val( val );
					else
						$hidden_input.val( '' );
					$hidden_input.trigger( 'change' );
				});;
			} else {
				$( this ).datetimepicker({
					format: visible_format,
				}).on( "dp.change", function( e ){
					$( this ).trigger( 'change' );
				} );
			}
		} );
	}
	
	try{
		if( CKEDITOR != undefined ){
			$( '.ckeditor_full' ).each( function(){
				if( $( this ).attr( 'id' ) != undefined )
					CKEDITOR.replace( $( this ).attr( 'id' ) );
				else
					console.log( 'Need ID of .ckeditor_full.' );
			} );
		}
	} catch( e ){
		/* ckeditor is not loaded */
	}
	
	$( '#thumbnail_container img' ).click( function(){
		$( this ).parents( '.tab-content' ).find( 'img' ).removeClass( 'selected' );
		$( this ).addClass( 'selected' );
		$( this ).parents( '.form-group' ).find( 'input[type=text]' ).filter( ':visible' ).val( $( this ).attr( 'data-original_name' ) );
	} );
} );
function thumbnail_container_auto_choose_img(){
	/* may not work accurately */
	var img_name = jQuery( '#primary_image' ).val();
	jQuery( '#thumbnail_modal' ).find( 'img' ).removeClass( 'selected' ).filter( '[data-original_name="'+img_name+'"]' ).addClass( 'selected' );
}