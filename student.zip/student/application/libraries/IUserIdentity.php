<?php
Class IUserIdentity {
	public $id;	/* uniquely identifies a user, can be a user_name or user_id */
	public $user_name;	/* user_name */
	public $password;		/* password */
	public $CI;
	
	/**
	 *  @brief Loads CodeIgnitor instance to class variable and loads session library
	 *  
	 *  @return Return_Description
	 *  
	 *  @details Loads CodeIgnitor instance to class variable and loads session library
	 */
	public function __construct(){

		$this->CI =& get_instance();
		$this->CI->load->library('session');
		
		if( $this->is_guest() == TRUE ){
			if(!array_key_exists('login_attempts', $_COOKIE))
			{
				setcookie("login_attempts", 0, time()+900, '/');
			}
		}
	
	}
	
	/**
	 *  @brief Pass user_name and password for current user
	 *  
	 *  @param [in] $user_name uniquely identifies a user in the system
	 *  @param [in] $password user's password
	 *  @return null
	 *  
	 *  @details Call this function first on order to set current user_name and password, using which the user will be authenticate(d) and then logged_in
	 */
	public function init( $user_name, $password ){
		$this->user_name = $user_name;
		$this->password = $password;
	}
	
	/**
	 *  @brief Log_in a user
	 *  
	 *  @return Returns true when user is successfully logged_in, and return false when user cannot be logged_in
	 *  
	 *  @details Logs in a user based in details set by init function
	 */
	public function login(){
		if( !empty( $this->user_name ) ){
			
			if( empty( $this->id ) ){
				if( $this->CI->session->userdata( 'id' ) != null )
					$this->id = $this->CI->session->userdata( 'id' );
				elseif( $this->CI->session->id != null )
					$this->id = $this->CI->session->id;
				else
					$this->id = $this->user_name;
			}
			
			$user_data = array(
				'user_name' => $this->user_name,
				'id' => 	$this->id,
				'logged_in' => true
			);
			// $user_data['logged_in'] = true;
			$this->CI->session->set_userdata($user_data);
			return true;	/* user has been logged_in */
		}
			return false;	/* unable to log_in the user */
	}
	
	/**
	 *  @brief Logs out current user
	 *  
	 *  @return Return_Description
	 *  
	 *  @details Logs out current user by deleting user's session
	 */
	public function logout(){
		$this->CI->session->sess_destroy();
	}
	
	/* authenticate function needs to be implemented */
	public function authenticate(){
		return false;	/* by default no user is valid user */
	}
	
	/**
	 *  @brief Checks if user is logged_in or not
	 *  
	 *  @return Returns true is user is not logged_in, and return false when user is logged_in
	 *  
	 *  @details Checks if user is logged_in or not
	 */
	public function is_guest(){
		if( $this->CI->session->userdata( 'logged_in' ) != NULL && $this->CI->session->userdata( 'logged_in' ) == TRUE )
			return false;
		return true;
	}
	
	/**
	 *  @brief Set a data associated with current user, in form of key => value pair
	 *  
	 *  @param [in] $key Key of the data
	 *  @param [in] $value Value of the data
	 *  @return null
	 *  
	 *  @details Set a data associated with current user, in form of key => value pair
	 */
	public function set_data( $key, $value ){
		$data = array( $key => $value );
		$this->CI->session->set_userdata($data);
	}
	
	/**
	 *  @brief Returns a  value of a key associated with current user, as set by set_data() function
	 *  
	 *  @param [in] $key Name of the key
	 *  @return Value of the key or null if key is not found
	 *  
	 *  @details Returns a  value of a key associated with current user, as set by set_data() function
	 */
	public function get_data( $key ){
		return $this->CI->session->userdata( $key );
	}
}
?>