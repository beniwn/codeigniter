<?php  
if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

include_once( dirname( __FILE__ ). '/IUserIdentity.php' );

class CUserIdentity extends IUserIdentity {
	
	public $valid_user = array(
		array(
			'id' => '0',
			'user_name' => 'admin',
			'password' => 'adminpass',
			'role'	=> 'admin',
		),
	);

	public function authenticate(){
		
		foreach( $this->valid_user as $user ){
			if( $user['user_name'] == $this->user_name && $user['password'] == $this->password ){
				$this->set_data( 'id', $user['id'] );
				$this->set_data( 'role', $user['role'] );
				return true;
			}
		}
		
		/* user was not found in static list so search in DB */
		/* check on vendor table */
		$this->CI->load->database();
		$this->CI->load->model('mvendor');
		
		$model = $this->CI->mvendor;
		$rows = $model->get_by( array( 'primary_email' => $this->user_name, 'password' => md5( $this->password ) ) );
		if( !empty( $rows ) ){
			$this->set_data( 'id', $rows->id );
			$this->set_data( 'role', 'vendor' );
			return true;
		}
		
		/* its not a vendor so search for client in DB */
		/* check on vendor table */
		$this->CI->load->database();
		$this->CI->load->model('mclient');
		
		$model = $this->CI->mclient;
		$rows = $model->get_by( array( 'email' => $this->user_name, 'password' => md5( $this->password ) ) );
		if( !empty( $rows ) ){
			$this->set_data( 'id', $rows->id );
			$this->set_data( 'role', 'client' );
			return true;
		}
		
		$this->CI->session->set_userdata( 'login_flash', 'Invalid User Name or Password !' );
		$this->CI->session->mark_as_flash( 'login_flash' );
		
		return false;
	}

}
?>