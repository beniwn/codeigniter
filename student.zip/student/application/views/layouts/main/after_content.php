			
	<script>
		var base_url = '<?php echo( base_url() ); ?>';
		var site_url = '<?php echo( site_url( '' ) ); ?>';
	</script>
	<script src="<?php echo( base_url( 'assets' ) ); ?>/vendors/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo( base_url( 'assets' ) ); ?>/js/main.js"></script>
</body>
</html>