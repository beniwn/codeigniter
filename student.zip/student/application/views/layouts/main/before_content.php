<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Maha Laxmi, Infra Services">
	<meta name="author" content="MahaLaxmi">

	<title><?php echo ( isset( $page_title ) )?( $page_title ):( 'Student' ); ?></title>
	<link rel="stylesheet" href="<?php echo( base_url( 'assets' ) ); ?>/css/normalize.css">
	<link rel="stylesheet" href="<?php echo( base_url( 'assets' ) ); ?>/css/bootstrap.css">
	<link rel="stylesheet" href="<?php echo( base_url( 'assets' ) ); ?>/css/style.css">
	<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

	
</head>
<body>
	<div class="container" id="body_wrapper">
		<header>
			
			
		</header>
		<div id="body_content">
		
			
			<div class="row">
				<div class="col-md-12">
				