 <style>
 .col-md-offset-10.col-md-2 {
    margin-bottom: 12px;
  
}
.btn_space{
  margin-right:10px;
}
 </style>
 <h2><?php echo( ( isset( $page_heading )?$page_heading:( ucfirst( $model->_table ) ) ) ); ?> 
	<small>
		<?php if( empty( $sub_heading ) )
				echo ( empty( $row->id ) )?'CREATE':'UPDATE';
			else
				echo( $sub_heading );
			?>
	</small>
</h2><div class="col-md-offset-10 col-md-2">
<a href="<?php echo( base_url( 'students/registration' ) ); ?>" class="btn btn-primary">Student Registration</a>
</div>
<div class="row">
	<div class="col-md-12">
		<table class="table table-bordered table-striped table-hover dataTable js-exportable">
              <thead>
                <tr>
                  <th> Name
                  </th>
                  <th>Email
                  </th>
                  <th>Mobile
                  </th>
                  <th>Address
                  </th>
				  <th>Edit/Delete</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach($students as $student){
			?>	
                <tr>
                  <td>
                    <?php echo $student->name;?>
                  </td>
                  <td>
                    <?php echo $student->email;?>
                  </td>
                  <td>
                    <?php echo $student->mobile;?>
                  </td>
                  <td>
                    <?php echo $student->address;?>
                  </td>
				  <td><div class="col-md-offset-10.col-md-2">
							<?php $edit_link = '';
							$delete_link = '';
							echo( anchor( site_url('students'. '/update/'. $student->id ), '<button type="button" class="btn btn-primary btn_space">Edit</button>' )  );
							
							echo( anchor( site_url( 'students'. '/delete/'. $student->id ), '<button type="button" class="btn btn-danger">Delete</button>' ) );?></td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
				
	</div>
</div>