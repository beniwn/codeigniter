 <style>
 .formlayout {
    box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12)!important;
    padding: 30px;
}
 </style>
 <center>
 <h2><?php echo( ( isset( $page_heading )?$page_heading:( ucfirst( $model->_table ) ) ) ); ?> 
    <small>
        <?php if (empty( $sub_heading )) {
                echo ( empty( $row->id ) )?'CREATE':'UPDATE';
} else {
    echo( $sub_heading );
} 
            ?>
    </small>
</h2>
</center>
<div class="row ">
    <div class="col-md-8 col-md-offset-2">
    <div class="formlayout">
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name <span class="required-field">*</span><small class="danger highlight "><?php echo form_error( 'name' ) ?></small></label>
                <input type="text" class="form-control" name="model[name]" id="name" placeholder="Name" value="<?php echo $row->name; ?>" />
            </div>
            
            <div class="form-group">
                <label for="email"><?php echo( $model->attributeLabels( 'email' ) ); ?> <span class="required-field">*</span><small class="danger highlight "><?php echo form_error( 'email' ) ?></small></label>
                <input type="text" class="form-control" name="model[email]" id="email" placeholder="Email" value="<?php echo $row->email; ?>" />
            </div>
            
            <div class="form-group">
                <label for="mobile"><?php echo( $model->attributeLabels( 'mobile' ) ); ?> <span class="required-field">*</span><small class="danger highlight "><?php echo form_error( 'mobile' ) ?></small></label>
                <input type="text" class="form-control" name="model[mobile]" id="mobile" placeholder="Contact Number" value="<?php echo $row->mobile; ?>" />
            </div>
            
            <div class="form-group">
                <label for="address"><?php echo( $model->attributeLabels( 'address' ) ); ?> <span class="required-field">*</span><small class="danger highlight "><?php echo form_error( 'address' ) ?></small></label>
                <textarea class="form-control" rows="3" name="model[address]" id="address" placeholder="Address"><?php echo $row->address; ?></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary"><?php echo ( empty( $row->id ) )?'Create':'Update' ?></button> 
            <a href="javascript:history.go( -1 );" class="btn btn-default">Cancel</a>
    </form>
    </div>
    </div>
</div>
