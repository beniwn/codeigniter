<h2><?php echo( ( isset( $page_heading )?$page_heading:( ucfirst( $model->_table ) ) ). ' <small>VIEW</small>' ); ?></h2>
<div class="row">
	<div class="col-md-12">
		<?php $controller_path = $this->router->directory. $this->router->class;	?>
		<a href="javascript:history.go(-1);" class="btn btn-default">Back</a>
		<a href="<?php echo( site_url( $controller_path. '/update/'. $row->id ) ); ?>" class="btn btn-primary">Update</a>
		<a href="<?php echo( site_url( $controller_path. '/delete/'. $row->id ) ); ?>" class="btn btn-danger">Delete</a>
		<a href="<?php echo( site_url( $controller_path. '/create' ) ); ?>" class="btn btn-info">Create</a>
		<br>
		<br>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<table class="table table-hover table-bordered table-striped">
			<thead>
				<tr>
					<th>Fields</th>
					<th>Value</th>
				</tr>
			</thead>
			<tbody>
					<?php
					if( empty( $remove_columns ) )
						$remove_columns = array();
						
					$labels = $model->attributeLabels();
					foreach( $labels as $col => $title ){
						if( in_array( $col, $remove_columns ) )
							continue;
						echo( '<tr>' );
							echo( '<td>'.$title.'</td>' );
							echo( '<td>'.$row->$col.'</td>' );
						echo( '</tr>' );
					}
					?>
			</tbody>
		</table>
	</div>
</div>

<div class="row">
	<div class="col-md-12">
		<?php $controller_path = $this->router->directory. $this->router->class;	?>
		<a href="javascript:history.go(-1);" class="btn btn-default">Back</a>
		<a href="<?php echo( site_url( $controller_path. '/update/'. $row->id ) ); ?>" class="btn btn-primary">Update</a>
		<a href="<?php echo( site_url( $controller_path. '/delete/'. $row->id ) ); ?>" class="btn btn-danger">Delete</a>
		<a href="<?php echo( site_url( $controller_path. '/create' ) ); ?>" class="btn btn-info">Create</a>
		<br>
		<br>
	</div>
</div>
