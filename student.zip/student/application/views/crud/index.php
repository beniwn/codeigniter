<script src="<?php echo( base_url( 'assets/vendors/datatables/js/jquery.dataTables.min.js' ) ); ?>" ></script>
<link href="<?php echo( base_url( 'assets/vendors/datatables/css/jquery.dataTables.css' ) ); ?>" rel="stylesheet" >
<h2><?php echo( isset( $page_heading )?$page_heading:( ucfirst( $model->_table ). '' ) ); ?> <small>LIST</small></h2>

<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<br>
<div class="row">
	<div class="col-md-12">
		<?php app::flash_messages(); ?>
	</div>
</div>
<div class="row">
<div class="table-responsive">
	<div class="col-md-12">
		<table class="table table-hover table-bordered table-striped data-table table">
			<thead>
				<tr>
				<?php 
				$controller_path = $this->router->directory. $this->router->class;
				if( !isset( $remove_columns ) )
					$remove_columns = array();
				$labels = $model->attributeLabels();
				foreach( $labels as $col => $title ){ 
					if( in_array( $col, $remove_columns ) )
						continue;
				?>
					<th><?php echo( $title ); ?></th>
			<?php	}
				?>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
					<?php
					if( empty( $condition ) )
						$data = $model->get_all();
					else 
						$data = $model->get_many_by( $condition );
						
					foreach( $data as $row ){
						echo( '<tr>' );
							foreach( $labels as $col => $title ){
								if( in_array( $col, $remove_columns ) )
									continue;
								echo( '<td>'.$row->$col.'</td>' );
							}
							
							$edit_link = '';
							$view_link = '';
							$delete_link = '';
							
							echo( '<td class="action">' );
							echo( anchor( site_url( $controller_path. '/update/'. $row->id ), '<img src="'.base_url( 'assets/img/edit.png' ).'" title="edit">' )  );
							echo( anchor( site_url( $controller_path. '/view/'. $row->id ), '<img src="'.base_url( 'assets/img/view.png' ).'" title="view">' )  );
							echo( anchor( site_url( $controller_path. '/delete/'. $row->id ), '<img src="'.base_url( 'assets/img/delete.png' ).'" title="delete">' ) );
							echo( '</td>' );
							
						echo( '</tr>' );
					}
					?>
			</tbody>
		</table>
	</div>
</div>
</div>
<br>
<div class="row">
	<div class="col-md-12">
		<?php echo anchor( site_url( $controller_path. '/create' ), 'Add New', array( 'class' => 'btn btn-primary '. ( ( isset( $add_new ) && isset( $add_new['class'] ) )?$add_new['class']:'' ) ) ); ?>
	</div>
</div>