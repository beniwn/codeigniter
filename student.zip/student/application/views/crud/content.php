<?php 
/* this file renders any content as set in $content variable */
echo( $content ); 
?>