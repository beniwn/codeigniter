<?php 
class Encryption {
	var $skey 	= "c7547c7wc7w6%#@%#@"; // you can change it anystrongkeywillwork
	
	public  function safe_b64encode($string) {
		$data = base64_encode($string);
		$data = str_replace(array('+','/','='),array('-','_',''),$data);
		return $data;
	}

	public function safe_b64decode($string) {
		$data = str_replace(array('-','_'),array('+','/'),$string);
		$mod4 = strlen($data) % 4;
		if ($mod4) {
		    $data .= substr('====', $mod4);
		}
		return base64_decode($data);
	}

	public  function encode($value){ 
		
		if(!$value){return false;}
		$text = $value;
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $this->skey, $text, MCRYPT_MODE_ECB, $iv);
		return trim($this->safe_b64encode($crypttext)); 
	}

	public function decode($value){
		
		if(!$value){return false;}
		$crypttext = $this->safe_b64decode($value); 
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $this->skey, $crypttext, MCRYPT_MODE_ECB, $iv);
		return trim($decrypttext);
	}
}


/* class app contains helper function to be used throughout the code */
class app {

	public static function get_enum_values( $table, $field ){
		
		$CI =& get_instance();
		$CI->load->database();
		
		// $this->load->database();
		$type = $CI->db->query( "SHOW COLUMNS FROM {$table} WHERE Field = '{$field}'" )->row( 0 )->Type;
		preg_match("/^enum\(\'(.*)\'\)$/", $type, $matches);
		$enum = explode("','", $matches[1]);
		return $enum;
	}
	
	public static function get_enum_as_option_html( $table, $field, $selected_value = null ){
		$options = app::get_enum_values( $table, $field );
		$option_html = '';
		foreach( $options as $k => $v )
			$option_html .= '<option value="'.$v.'" '.( ( $selected_value == $v )?'selected':'' ).'>'.( ucwords( str_replace( '_', ' ', $v ) ) ).'</option>';
		return $option_html;
	}
	
	public static function get_option_html( $options, $selected = '', $associated_array = true ){
		if( is_string( $selected ) )
			$selected = array( $selected );
		$html = '';
		foreach( $options as $k => $v ){
			if( !$associated_array ){
				$k = $v;
				$v = ucwords( $v );
			}
			$html .= '<option value="'.$k.'" '.( ( in_array( $k, $selected ) )?'selected':'' ).' >'.$v.'</option>';
		}
		return $html;
	}

	public static function get_fk_as_option_html( $table, $field, $selected_value = null, $displayed_column = null, $condition = '1' ){
		$CI =& get_instance();
		$CI->load->database();
		$db_name = $CI->db->database;
		
		$sql_key_col_usage = 'select REFERENCED_TABLE_NAME,REFERENCED_COLUMN_NAME from INFORMATION_SCHEMA.KEY_COLUMN_USAGE where TABLE_NAME = "'.$table.'" && COLUMN_NAME = "'.$field.'" ';
		
		$relations = $CI->db->query( $sql_key_col_usage )->result();

		$col = '';
		if( $displayed_column == null ){
			if( count( $CI->db->query( 'SHOW COLUMNS from '.$relations[0]->REFERENCED_TABLE_NAME.' where Field = "title" ' )->result() ) == 1 )
				$displayed_column = 'title';
			elseif( count( $CI->db->query( 'SHOW COLUMNS from '.$relations[0]->REFERENCED_TABLE_NAME.' where Field = "name" ' )->result() ) == 1 )
				$displayed_column = 'name';
		}
		
		$sql_fetch_data = "select {$relations[0]->REFERENCED_COLUMN_NAME} id, {$displayed_column} title from {$relations[0]->REFERENCED_TABLE_NAME} where {$condition} ";
		$rows = $CI->db->query( $sql_fetch_data )->result();
		
		$option_html = '';
		
		/* check if $field can be null */
		$field_detail = $CI->db->query( 'SHOW COLUMNS from '.$table.' where Field = "'.$field.'" ' )->result();
		if( $field_detail[0]->Null == 'YES' )
			$option_html .= '<option value="">Choose...</option>';
		
		foreach( $rows as $row ){
			if( $selected_value == $row->id )
				$option_html .= '<option value="'.$row->id.'" selected>'.$row->title.'</option>';
			else
				$option_html .= '<option value="'.$row->id.'">'.$row->title.'</option>';
		}
		
		return $option_html;
	}
	
	public static function get_table_field_as_option_html( $table_name, $key_field = 'id', $value_field = 'title', $selected_value = null, $where = '1' ){
		$CI =& get_instance();
		$CI->load->database();
		
		$query = "select * from {$table_name} where {$where} ";
		$rows = $CI->db->query( $query )->result();
		
		$option_html = '';
		foreach( $rows as $row ){
			if( $selected_value == $row->$key_field )
				$option_html .= '<option value="'.$row->$key_field.'" selected>'.$row->$value_field.'</option>';
			else
				$option_html .= '<option value="'.$row->$key_field.'">'.$row->$value_field.'</option>';
		}
		
		return $option_html;
	}
	
	public static function set_flash( $category, $message ){
		$CI =& get_instance();
		$CI->load->library( 'session' );
		
		$msgs = $CI->session->$category;
		if( empty( $msgs ) )
			$msgs = array( $message );
		else
			$msgs[] = $message;
		$CI->session->$category = $msgs;
		$CI->session->mark_as_flash( $category );
	}
	
	public static function get_flash_messages( $category ){
		$CI =& get_instance();
		$CI->load->library( 'session' );
		
		$msgs = $CI->session->$category;
		$CI->session->unset_userdata( $category );
		return $msgs;
	}
	
	public static function has_flash( $category ){
		$CI =& get_instance();
		$CI->load->library( 'session' );
		
		$msgs = $CI->session->$category;
		if( empty( $msgs ) )
			return false;
		else
			return true;
	}
	
	public static function flash_messages( $model = null, $category = array( 'danger', 'success', 'info', 'notice' ) ){
		$msg_html = '';
		foreach( $category as $cat ){
			$msgs = app::get_flash_messages( $cat );
			if( !empty( $msgs ) )
				foreach( $msgs as $msg ){
					$msg_html .= '<div class="alert alert-'.$cat.' alert-dismissible fade in" role="alert"> 
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					'.$msg.'
					</div>';
				}
		}
		if( !empty( $model ) ){
			$errors = $model->get_errors();
			foreach( $errors as $err )
				$msg_html .= '<div class="alert alert-danger alert-dismissible fade in" role="alert"> 
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				'.$err.'
				</div>';
			
		}
		
		echo $msg_html;
		
	}

	static function get_random_string( $length = 15, $char_set = '' ) {
		switch( $char_set ){
			case 'uc_alphabet':
				$str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
				break;
			case 'lc_alphabet':
				$str = 'abcdefghijklmnopqrstuvwxyz';
				break;
			case 'number':
				$str = '0123456789';
				break;
			default :
				$str = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		}
		return substr(str_shuffle( $str ), 0, $length);
	}
	
	public static function encrypt( $value ){
		$en = new Encryption;
		return $en->encode( $value );
	}
	
	public static function decrypt( $value ){
		$en = new Encryption;
		return $en->decode( $value );
	}
	
	static function get_thumbnail_html( $fileName, $width, $height, $maintain_ratio = true, $html_options = array( 'class' => '' ) ) {
		$thumb_src = app::get_thumbnail_src( $fileName, $width, $height, $maintain_ratio, $html_options );
		
		$attrib = array();
		foreach( $html_options as $k => $v )
			$attrib[] = $k. '="'.$v.'"';
		return '<img src="'.$thumb_src.'" alt="'.basename( $fileName ).'" data-original_name="'.basename( $fileName ).'" '.implode( ' ', $attrib ).' >';
	}
	
	public static function get_thumbnail_src( $fileName, $width, $height, $maintain_ratio = true, $html_options = array( 'class' => '' ) ){
		if( empty( $fileName ) )
			return '';
		
		$CI =& get_instance();
		$config['new_image'] = FCPATH. '/assets/uploads/thumbs/'. $width. 'x'. $height. '_'. $fileName;
		
		$resultant_file_path = str_replace( '.', '_thumb.', $config['new_image'] );
		if( !file_exists( $resultant_file_path ) ){
			$CI->load->library('image_lib');
			$config['image_library'] = 'gd2';
			$config['source_image'] = FCPATH. '/assets/uploads/'.$fileName;       
			$config['create_thumb'] = TRUE;
			$config['maintain_ratio'] = $maintain_ratio;
			$config['width'] = $width;
			$config['height'] = $height;
			$CI->image_lib->initialize($config);
			if(!$CI->image_lib->resize())
			{ 
			    echo $CI->image_lib->display_errors();
			}        
		}
		return base_url( 'assets/uploads/thumbs/'. basename( $resultant_file_path ) );
	}
	
	static function get_thumbnails_in_tabs( $selected_image_name = '' ){
		$image_per_page = 35;
		$thumb_width = 60;
		$thumb_height = 60;
		
		$images_file_path = array();
		
		$image_dir = FCPATH. '/assets/uploads/';
		$files = scandir( $image_dir );
		foreach( $files as $f ){
			if( is_file( $image_dir. $f ) && in_array( pathinfo( $image_dir. $f, PATHINFO_EXTENSION ), array( 'jpg', 'png', 'gif', 'JPG', 'PNG', 'GIF' ) ) ){
				$images_file_path[] = $f;
			}
		}
		
		$tab_head = '';
		$tab_body = '';
		$tab = '';
		
		$all_image_displayed = false;
		$page_number = 1;
		while( !$all_image_displayed ){
			$tab_head .= '<li class="'.( ( $page_number == 1 )?'active':'' ).'"><a href="#tab'.$page_number.'"  data-toggle="tab">'.$page_number.'</a></li>';
			$index = 0;
			$content = '';
			while( $index < $image_per_page ){
				if(  isset( $images_file_path[( $page_number -1 )*$image_per_page + $index ] ) ){
					$current_image_name = $images_file_path[( $page_number -1 )*$image_per_page + $index ];
					$content .= app::get_thumbnail_html( $current_image_name, $thumb_width, $thumb_height, false, array( 'class' => ( ( $current_image_name == $selected_image_name )?'selected':'' ) ) );
				} else {
					$all_image_displayed = true;
				}
					$index++;
			}
			$tab_body .= '<div role="tabpanel" class="tab-pane fade '.( ( $page_number == 1 )?'in active':'' ).'" id="tab'.$page_number.'">'.$content.'</div>';
			$page_number++;
		}
		
		$tab = '<div id="thumbnail_container"><ul  class="nav nav-tabs" role="tablist">'.$tab_head.'</ul>'. '<div class="tab-content">'.$tab_body.'</div></div>';
		
		$modal_html = app::get_modal_html( '<a onclick="thumbnail_container_auto_choose_img();" class=" input-group-addon btn" data-toggle="modal" data-target="#thumbnail_modal">Choose Image</a>',  'Choose Images', $tab );
		return $modal_html. ( '<div class="thumb_preview">'.app::get_thumbnail_html( $selected_image_name, $thumb_width, $thumb_height, false ).'</div>' );
	}
	
	static function get_modal_html( $trigger_button = '',  $title = 'Popup', $body_content = '', $footer_content = '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' ){
		if( $trigger_button == '' )
			$trigger_button = '<button type="button" class="btn btn-primary btn-lg hidde1n" data-toggle="modal" data-target="#thumbnail_modal">Launch demo </button>';
		$html = '<!-- Button trigger modal -->
	'.$trigger_button.'
<!-- Modal -->
<div class="modal fade" id="thumbnail_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">'.$title.'</h4>
      </div>
      <div class="modal-body">
       '.$body_content.'
      </div>
      <div class="modal-footer">
	'.$footer_content.'
      </div>
    </div>
  </div>
</div>';
		return $html;
	}
	
	public static function get_captcha_code( $captcha_length = 6, $char_set = '' ){
		$CI =& get_instance();
		$CI->load->model( 'msettingadmin' );
		$static_append = $CI->msettingadmin->get_value( 'Captcha Generation Key', 'uiaywuda78q1t2112e', 'Enter some strong key' );
		$rand_str = app::get_random_string( $captcha_length, $char_set );
		$captcha_verify_code = sha1( $rand_str. $static_append );
		return array( $rand_str, $captcha_verify_code );
	}
	
	public static function get_captcha( $captcha_length = 6, $char_set = '' ){
		$CI =& get_instance();
		$CI->load->helper( 'captcha' );
		$code = app::get_captcha_code( $captcha_length, $char_set );
		
		$vals = array(
			'word'          => $code[0],
			'img_path'      => FCPATH. 'assets/captcha/',
			'img_url'       => site_url( 'assets/captcha/' ),
			'font_path'     => FCPATH. 'assets/fonts/monofont.ttf',
			'img_width'     => '150',
			'img_height'    => 30,
			'expiration'    => 7200,
			'word_length'   => 8,
			'font_size'     => 20,
			'img_id'        => 'Imageid',
			'pool'          => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',

			// White background and border, black text and red grid
			'colors'        => array(
				'background' => array(255, 255, 255),
				'border' => array(255, 255, 255),
				'text' => array(0, 0, 0),
				'grid' => array(255, 40, 40)
			)
		);

		$cap = create_captcha($vals);
		$cap['verify_code'] = $code[1];
		return $cap;
	}
	
	public static function get_captcha_html( $captcha_length = 6, $char_set = '' ){
		$captcha = app::get_captcha( $captcha_length, $char_set );
		$html = '<input autocomplete="off" type="hidden" name="captcha_verify_code" value="'.$captcha['verify_code'].'">'. $captcha['image'];
		return $html;
	}
	
	public static function verify_captcha( $user_input, $security_code ){
		$CI =& get_instance();
		$CI->load->model( 'msettingadmin' );
		$static_append = $CI->msettingadmin->get_value( 'Captcha Generation Key', 'uiaywuda78q1t2112e', 'Enter some strong key' );
		if( $security_code == sha1( $user_input. $static_append ) )
			return true;
		else
			return false;
	}
	
	public static function get_excerpt( $text, $no_of_character = 100, $strip_html = true ){
		if( strlen( $text ) <  $no_of_character )
			return ( $strip_html )?strip_tags( $text ):$text;
		else
			return substr( ( ( $strip_html )?strip_tags( $text ):$text), 0, strpos( $text, ' ', $no_of_character ) );
	}
}
 
?>