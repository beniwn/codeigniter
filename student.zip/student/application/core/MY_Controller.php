<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BaseController extends CI_Controller {
	public $layout = "main";
	public $user;
	
	public function __construct(){
		parent::__construct();
		$this->load->library( 'CUserIdentity' );
		$this->load->database();
		$this->load->helper( 'url' );
		$this->load->model( 'basemodel' );
		$this->load->model( 'msettingadmin' );
		$this->load->helper( 'app' );
	}
	
	/**
	 *  @brief Renders a content of view file in between a set layout
	 *  
	 *  @param [in] $view_name Name of the view
	 *  @param [in] $data Data to be passed to view
	 *  @return null
	 *  
	 *  @details Renders content of view file in between a set layout
	 */
	public function _render( $view_name = null, $data = null ){
		if( empty( $view_name ) )
			$view_name = strtolower( $this->router->fetch_method() );
			
		$this->load->view('layouts/'. $this->layout. '/before_content', $data);
		$this->_render_partial( $view_name, $data );
		$this->load->view('layouts/'. $this->layout. '/after_content', $data);

	}
	
	public function _render_layout( $layout_type = 'before_content', $data = null ){
		$this->load->view('layouts/'. $this->layout. '/'. $layout_type, $data);
	}
	
	public function _render_content( $content = '' ){
		$this->load->view( 'crud/content', array( 'content' => $content ) );
	}
	/**
	 *  @brief Renders a content of view file only
	 *  
	 *  @param [in] $view_name Name of the view
	 *  @param [in] $data Data to be passed to view
	 *  @return null
	 *  
	 *  @details Renders content of view file only
	 */
	public function _render_partial( $view_name, $data ){
		if( empty( $view_name ) )
			$view_name = strtolower( $this->router->fetch_method() );
		
		$view_base_path = APPPATH. '/views/';
		$relative_view_path = strtolower( $this->router->directory. $this->router->class ). '/'. $view_name;
		if( !file_exists( $view_base_path. $relative_view_path. '.php' ) ){
			/* view file was not found at controller path structure so check for non-relative path */
			$relative_view_path = $view_name;
			if( !file_exists( $view_base_path. $relative_view_path. '.php' ) )
				show_404();
			else 
				$this->load->view( $relative_view_path, $data);
		} else {
			$this->load->view( $relative_view_path, $data);
		}
	}
	
	public function	_redirect( $view_name = 'index' ){
		$relative_view_name = strtolower( $this->router->directory. $this->router->class ). '/'. $view_name;
		redirect( $relative_view_name );
	}
}


class FilteredBaseController extends BaseController {
	
	/* overrides the default _remap function */
	public function _remap( $method_name, $params = array() ){
		if( method_exists( $this, $method_name ) && $this->_check_access_to_method( $method_name ) ){
			return call_user_func_array( array( $this, $method_name ), $params );
		} else {
			show_error( 'Requested function not found : '. $method_name );
			// show_404();
		}
	}
	
	/**
	 *  @brief Checks access of method by use
	 *  
	 *  @param [in] $method_name Parameter_Description
	 *  @return Return_Description
	 *  
	 *  @details Details
	 */
	public function _check_access_to_method( $method_name ){

		if( method_exists( $this, '_access_rules' ) ){
			$allowed = false;	/* by default access is not allowed is rule allowing the access is not provided */
			
			$rules = $this->_access_rules();
			
			foreach( $rules as $rule ){
				$access = '';
				$actions = array();
				$rule_array = array();
				
				// var_dump( $rule );
				foreach( $rule as $k => $v ){
				// echo( '<br><br><br>' );
					if( $k === 0 ){
						// var_dump( $k );
						// var_dump( $v );
						$access = $v;
					}else if(  strcmp( $k, 'actions' ) == 0 ){
						$actions = $v;
					} else {
						/* else others may be rules */
						$rule_array = array( $k, $v );
					}
				}
				
				// echo( '<br><br><br>' );
				// var_dump( $access );
				// var_dump( $actions );
				// var_dump( $rule_array );
				
				
				/* check if action exists in current rule */
				if( is_array( $actions ) && ( in_array( $method_name, $actions ) || in_array( '*', $actions ) ) || !is_array( $actions ) && ( in_array( $actions, array( $method_name, '*' ) ) )  ){
					/* check if user matches for current rule */
					$user_data = $this->cuseridentity->get_data( $rule_array[0] );
					
					/* matches 'user_name' => array( 'aman', 'binay_002' )     or matches    'user_name' => array( '*' )  */
					$condition_for_array = is_array( $rule_array[1] ) && ( in_array( $user_data, $rule_array[1] ) || in_array( '*', $rule_array[1] ) );
					
					/* matches 'user_name' => 'aman'   or matches  'user_name' => '*' */
					$condition_for_non_array = !is_array( $rule_array[1] ) && ( in_array( $rule_array[1], array( $user_data, '*' ) ) );
					
					/* matches 'user' => '@'   or matches 'user' => array( '@' )  for logged_in users only */
					$condition_for_special_char = ( $user_data == null ) && $rule_array[0] == 'user' && ( is_array( $rule_array[1] ) && in_array( '@', $rule_array[1] ) || !is_array( $rule_array ) &&  $rule_array[1] == '@' ) && !$this->cuseridentity->is_guest();
					
					// var_dump( $condition_for_array );
					// var_dump( $condition_for_non_array );
					// var_dump( $condition_for_special_char );
					
					
					if( $condition_for_array || $condition_for_non_array || $condition_for_special_char ){
						
						/* both action and user is matching with current rule so set access to action according to access variable */
						if( $access == 'allow' )
							$allowed = true;
						elseif( $access == 'deny' )
							$allowed = false;
					
					}
				}
				
			}
			
			return $allowed;
			
		} else 
			return true;	/* allow access if _access_rules function is not defined in controller */
	}
}

class CrudController extends FilteredBaseController {

	public $model;
	public $page_heading = 'Heading';
	
	public function index(){
		$this->_render( "crud/index", array(
			"model" => $this->model,
			"remove_columns" => array( "" ),
			"page_heading" => $this->page_heading,
		) );
	}
	
	public function view( $id ){
		$row = $this->model->get( $id );
		$this->_render( "crud/view", array(
			"model" => $this->model,
			"page_heading" => $this->page_heading,
			"row" => $row,
		) );
	}
	
	public function update( $id ){
		$row = $this->model->get( $id );
		if( !empty( $_POST["model"] ) ){
			// $_POST["model"]["update_time"] = date( "Y-m-d H:i:s" );
			$this->model->update( $id, $_POST["model"] );
			$row = $this->model->get( $id );
			app::set_flash( "success", "Record is updated." );
			$this->_redirect( "index" );
		}
		$this->_render( "form", array(
			"model" => $this->model,
			"page_heading" => $this->page_heading,
			"row" => $row,
		) );
	}
	
	public function create(){
		
		$row = $this->model->set_attribute( ( isset( $_POST["model"] ) )?$_POST["model"]:array() );
		
		if( !empty( $_POST["model"] ) ){
			// $_POST["model"]["create_time"] = date( "Y-m-d H:i:s" );
			// $_POST["model"]["update_time"] = date( "Y-m-d H:i:s" );
			$id = $this->model->insert( $_POST["model"] );
			if( $id != null ){
				$row = $this->model->get( $id );
				app::set_flash( "success", "Record is added." );
				$this->_redirect( "index" );
			}
		}
		$this->_render( "form", array(
			"model" => $this->model,
			"page_heading" => $this->page_heading,
			"row" => $row,
		) );
	}
	
	public function delete( $id ){
		if( $this->model->get( $id ) ){
			$this->model->delete( $id );
			app::set_flash( "success", "A record has been deleted." );
		} else{
			app::set_flash( "danger", "Could not find the record !" );
			app::set_flash( "success", "No record was deleted." );
		}
		$this->_redirect( "index" );
	}

}

/* class to load admin layout */
class BackendController extends FilteredBaseController {
	public $layout = "admin";
	public function __construct(){
		parent::__construct();
		
	}
}

/* class to load admin layout */
class BackendcrudController extends CrudController {
	public $layout = "admin";
	public function __construct(){
		parent::__construct();
		
	}
}

class FrontendController extends FilteredBaseController {
	public $layout = "main";
	
	public function __construct(){
		parent::__construct();
		
	}
}
 ?>