<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Students extends FrontendController {

	public $model;
	public $page_heading = 'Student List';

	function __construct(){
		parent::__construct();
		$this->load->model('muser');
		$this->load->library('form_validation');
		$this->model = $this->muser;
	}

	public function _access_rules(){
		return array(
			
			array(
				'allow',
				'actions' => array( 'registration', 'student_list','delete','update' ),
				'user_name' => array( '*' )
			),
		);
	}

	public function registration(){
		$row = $this->model->set_attribute( ( isset( $_POST["model"] ) )?$_POST["model"]:array() );
		
		if( !empty( $_POST["model"] ) ){
			
			 $id = $this->db->insert('student', $_POST["model"] );
				//$id = $this->model->insert( $_POST["model"] );
			}
		$this->_render( "registration", array(
			"model" => $this->model,
			"page_heading" => 'Student ',
			"sub_heading"	=>	'REGISTRATION',
			"row" => $row,
		) );
	}
	public function student_list(){
		$this->load->model('muser');
		$students=$this->muser->get_all();
		//var_dump($students);
		$this->_render( "students/student_list", array(
			"model" =>null,
			'students'=>$students,
			"page_heading" => $this->page_heading,
		) );
	}

	public function delete( $id ){
		if( $this->model->get( $id ) ){
			$this->model->delete( $id );
			app::set_flash( "success", "A record has been deleted." );
		} else{
			app::set_flash( "danger", "Could not find the record !" );
			app::set_flash( "success", "No record was deleted." );
		}
		if( !empty( $_GET['redirect'] ) ){
			redirect( urldecode( $_GET['redirect'] ) );
		}
		$this->_redirect( "student_list" );
	}
		public function update( $id ){
		$row = $this->model->get( $id );
		if( !empty( $_POST["model"] ) ){
			$this->model->update( $id, $_POST["model"] );
			$row = $this->model->get( $id );
			app::set_flash( "success", "Record is updated." );
			$this->_redirect( "student_list" );
		}
		$this->_render( "registration", array(
			"model" => $this->model,
			"page_heading" => $this->page_heading,
			"row" => $row,
		) );
	}
	
	
}