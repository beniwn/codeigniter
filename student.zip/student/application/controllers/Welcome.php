<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends FrontendController {
	
	public function _access_rules(){
		return array(
			array(
				'deny',
				'actions' => array( 'index' ),
				'user_name' => array( 'admin' ),
			),
			array(
				'allow',
				'actions' => array( '*' ),
				'user' => array( '*' )
			),
			// array(
				// 'deny',
				// 'actions' => array( 'index' ),
				// 'id'	=> array( '*' ),
			// )
			// array(
				// 'allow',
				// 'actions' => array( 'login' ),
				// 'user_name' => array( '*' )
			// )
		);
	}
	
	public function index()
	{
		if( $this->cuseridentity->is_guest() == true ){
			echo( 'You are guest' );
		}else {
			echo( 'You are a valid user' );
		}
		// $this->render();
		$this->load->view('welcome_message');
	}
	
	public function checkuser(){
		if( $this->cuseridentity->is_guest() == true ){
			echo( 'You are guest' );
		}else {
			echo( 'You are a valid user' );
		}
		// $this->render();
		$this->load->view('welcome_message');
	}
	
	public function login(){
		/* try to login a user */
		$this->cuseridentity->init( 'admin', 'adminpass' );
		if( $this->cuseridentity->authenticate() && $this->cuseridentity->login() )
			$aa = '';
	}
	
	public function logout(){
		$this->cuseridentity->logout();
	}
	
}
?>