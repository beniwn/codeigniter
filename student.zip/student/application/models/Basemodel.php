<?php

if (!defined('BASEPATH'))  exit('No direct script access allowed');

class BaseModel extends My_Model {

	public $validate = array();
	
	public function __construct(){
		/* fill up validation rules */
		$this->fill_up_validation_rule();
		$this->load->database();
		parent::__construct();
	}
	
	public function rules(){
		return array();
	}
	
	public function set_attribute( $data = array() ) {
		$class = get_class( $this );
		$object = new $class;
		
		$row = $this->attributeLabels();
		
		foreach( $row as $field => $title ) {
			$object->$field = ( isset( $data[$field] ) )?$data[$field]:null;
		}
		return $object;
	}
	
	public function fill_up_validation_rule(){
		
		if( !empty( $this->validate ) )
			return;
			
		$new_rules = array();
		$rules = $this->rules();
		
		foreach( $rules as $field => $rule ){
			$new_rules[] = array(
				'field' => $field,
				'label' => $this->attributeLabels( $field ),
				'rules' => $rule,
			);
		}
		$this->validate = $new_rules;
	}
	
	public function get_errors(){
		$this->validate( $this );
		$errors = array();
		$row = $this->attributeLabels();
		foreach( $row as $field => $label ){
			$err = form_error( $field );
			if( !empty( $err ) )
				$errors[] = $err;
		}
		return $errors;
	}
}
