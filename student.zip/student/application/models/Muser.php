<?php
if( !defined( 'BASEPATH' ) )
	exit( 'No direct script access allowed' );

class Muser extends BaseModel {
	public $_table = "student";
	public $debug = array();

	public function rules(){
		return array(
			'name'	=>	'required|max_length[64]',
			'email'	=>	'max_length[65535]',
			'mobile'	=>	'required|max_length[64]',
			'address'	=>	'required|max_length[256]',
			
		);
	}
	
	public function attributeLabels( $col = null ){
		$ret = array(
			'id'	=>	'ID',
			'name'	=>	'Name',
			'email'	=>	'Email',
			'mobile'	=>	'Mobile',
			'address'	=>	'Address',
			
		);
		return ( empty( $col ) )?$ret:$ret[$col];
	}
	
	
}
?>