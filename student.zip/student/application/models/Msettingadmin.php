<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Msettingadmin extends BaseModel {
	public $_table = 'setting_admin';

	
	public function __construct(){
		/* fill up validation rules */
		$this->fill_up_validation_rule();
		$this->load->database();
		parent::__construct();
	}
	public $validate = array(
	);
	
	public function rules1(){
		return array(
			'name' => 'required',
		);
	}
	
	public function attributeLabels( $col = null ){
		$ret = array(
			'id'	=> 'ID',
			'name'	=> 'Name',
			'value' => 'Value',
			'help_text' => 'Help Text',
		);
		return ( empty( $col ) )?$ret:$ret[$col];
	}
	
	public function get_value( $name, $default_value = null, $help_text = null ){
		$row = $this->get_by( array( 'name' => $name ) );
		if( $row == null ){
			$obj = array( 'name' => $name, 'value' => $default_value, 'help_text' => $help_text );
			$id = $this->insert( $obj );
			// echo( $this->db->error_message( )); 
			// echo( validation_errors() );
// echo form_error( 'id' );
// echo form_error( 'name' );
// echo form_error( 'value' );
// echo form_error( 'help_text' );
			return $default_value;
		} else
			return $row->value;
	}
	
}
